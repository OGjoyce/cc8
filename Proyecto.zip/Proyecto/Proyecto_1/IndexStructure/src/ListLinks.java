package IndexStructurePack;

import org.jsoup.Jsoup;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.io.IOException;
import java.util.*;
import java.net.*;

import org.json.simple.JSONObject;;

public class ListLinks {
    @SuppressWarnings("resource")
    public static String path = "C:/Users/julio/Desktop/jQuery/";
	public static PrintWriter writer;
	public static ArrayList<String> linkAnalizado = new ArrayList<String>();
    public static Hashtable<String, ArrayList<String>> parentChildren = new Hashtable<String, ArrayList<String>>();
	public static void main(String[] args) throws Exception {
        print("Ingrese un sitio para analizar");
		Scanner sc = new Scanner(System.in);
        String url = sc.nextLine();
        print("Analizando %s...", url);
        writer = new PrintWriter(path + "indexPagina.html");
    	writer.println("<html>");
    	writer.println("<head>");
    	writer.println("<title>Displaying Sitemap</title>");
    	writer.println("</head>");
    	writer.println("<body>");
    	writer.println("<h2>Sitemapping: " + url + "</h2><br>");
    	writer.println("<div id = \"data\">");
    	writer.println("<ul>");
    	writer.println("\t<li> NODO INICIAL: " + url);
        getLinks(url);
        writer.println("\t</li>");
    	writer.println("</ul>");
    	writer.println("</div>");
    	writer.println("<a href = \"puertos.html\"> RESUMEN DE PUERTOS ABIERTOS </a>");
    	writer.println("<script src = \"js/jquery-3.3.1.min.js\" type=\"text/javascript\"></script>");
    	writer.println("<script src = \"js/vakata-jstree-0097fab/dist/jstree.min.js\"></script>");
    	writer.println("<script src = \"js/script.js\"></script>");
    	writer.println("</body>");
    	writer.println("</html>");
    	writer.close();
    	//getMedia(url);
    	getPorts(url);
    }

    private static void print(String msg, Object... args) {
        System.out.println(String.format(msg, args));
    }

    
    private static String trim(String s, int width) {
        if (s.length() > width)
            return s.substring(0, width-1) + ".";
        else
            return s;
    }

    
    private static void getMeta(String url) throws Exception {
    	Document doc = Jsoup.connect(url).get();
        Elements meta = doc.select("meta");

        print("\nMetadata: (%d)", meta.size());
        for (Element data : meta) {	
        	if(!data.attr("charset").equals("") && data.attr("charset") != null) {
        		//print(" * %s: <%s> (%s) content: %s", data.tagName(), data.attr("charset"), data.attr("name"), data.attr("content"));
        		print(" * %s charset: <%s>", data.tagName(), data.attr("charset"));
        	}
        	else if(!data.attr("name").equals("") && data.attr("name") != null) {
        		print(" * %s name: <%s>", data.tagName(), data.attr("name"));
        	}
        	else if(!data.attr("content").equals("") && data.attr("content") != null) {
        		print(" * %s content: <%s>", data.tagName(), data.attr("content"));
        	}
        	else {
        		print(" * %s", data.tagName());
        	}
        }
    }
    
    
    private static void getLinks(String url) throws Exception{
   	 	Document doc = Jsoup.connect(url).get();
   	 	Elements links = doc.select("a[href]");
        linkAnalizado.add(url);
        //print("\nLinks: (%d)", links.size());
        writer.println("\t<ul>");
        for (int i=1; i < links.size(); i++) {
       	 	try {	
        		Element link = links.get(i);
       	 		//print(" * a: <%s>  (%s)", link.attr("abs:href"), trim(link.text(), 35));
       	 		if(!linkAnalizado.contains(trim(link.text(), 35)) && !trim(link.text(), 35).isEmpty()){
       	 			linkAnalizado.add(link.attr("abs:href"));
       	 			writer.println("\t\t<li> " + trim(link.text(), 35) + ": " + link.attr("abs:href"));
       	 			getChildrenLinks(link.attr("abs:href"));
       	 		}
        	}catch(Exception e) {
        	
        	}
        }
        writer.println("\t</ul>");
   }
    
    private static void getChildrenLinks(String url) throws Exception{
   	 	Document doc = Jsoup.connect(url).get();
   	 	Elements links = doc.select("a[href]");
        linkAnalizado.add(url);
       // print("\nLinks: (%d)", links.size());
        writer.println("\t\t\t<ul>");
        for (int i=1; i < links.size(); i++) {
       	 	try {	
        		Element link = links.get(i);
       	 		//print(" * a: <%s>  (%s)", link.attr("abs:href"), trim(link.text(), 35));
       	 		if(!linkAnalizado.contains(trim(link.text(), 35)) && !trim(link.text(), 35).isEmpty()){
       	 			linkAnalizado.add(link.attr("abs:href"));
       	 			writer.println("\t\t\t\t<li>" + trim(link.text(), 35) + ": " +link.attr("abs:href") + "</li>");
       	 		}
        	}catch(Exception e) {
        	
        	}
        }
        writer.println("\t\t\t</ul>");
        writer.println("\t\t</li>");
   }

    
   	private static void getMedia(String url) throws Exception{
   		PrintWriter wrt = new PrintWriter(path + "media.html");
    	wrt.println("<html>");
    	wrt.println("<body>");
    	wrt.println("<title>Media obtenida</title>");
    	wrt.println("<h1>Media Obtenida</h1>");
        Document doc = Jsoup.connect(url).get();
        Elements media = doc.select("[src]");
        print("\nMedia: (%d)", media.size());
        for (Element src : media) {
            if (src.tagName().equals("img"))
                wrt.println("<h2>" +src.tagName() + " " + src.attr("abs:src") + " " + src.attr("width") + " " + src.attr("height") + " " +trim(src.attr("alt"), 20) + "</h2>");
            else
                wrt.println("<h2>" + src.tagName() + " " + src.attr("abs:src") + "</h2>");
        }
        wrt.println("</body>");
    	wrt.println("</html>");
        wrt.close();
    }

    
   	private static void getPorts(String hostName) throws Exception{
        PrintWriter escritorDePuertos = new PrintWriter(path + "puertos.html");
    	URL url = new URL(hostName);
    	String host = url.getHost();
    	escritorDePuertos.println("<html>");
    	escritorDePuertos.println("\t<body>");
    	escritorDePuertos.println("<title>resumen de puertos abiertos</title>");
    	escritorDePuertos.println("<h1>Resumen de puertos abiertos</h1>");
    	for(int i = 0; i <= 1024; i++) {
    		Socket socket = new Socket();
        	try {
        		socket.connect(new InetSocketAddress(host,i), 100);
        		socket.close();
        		escritorDePuertos.println("\t<h2>- El Puerto " + i + " esta abierto.</h2>");
        		
        	}catch(IOException e) {

        	}
        }
    	escritorDePuertos.println("\t<h2>Fin de Resumen de Puertos principales abiertos</h2>");

    	escritorDePuertos.println("\t</body>");
    	escritorDePuertos.println("</html>");
    	escritorDePuertos.close();
    }
}