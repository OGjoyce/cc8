package IndexStructurePack;

import java.util.*;

public class Tree<T> {
    private Node<T> root;

    public Tree(T rootData) {
        root = new Node<T>(rootData);
        root.data = rootData;
        root.children = new ArrayList<Node<T>>();
    }

    public static class Node<T> {
        private T data;
        private Node<T> parent;
        private List<Node<T>> children;
        
        public Node(T data) {
            this.data = data;
        }

        public Node(T data, Node<T> parent) {
            this.data = data;
            this.parent = parent;
        }

        public List<Node<T>> getChildren() {
            return children;
        }

        public void setParent(Node<T> parent) {
            parent.addChild(this);
            this.parent = parent;
        }

        public void addChild(T data) {
            Node<T> child = new Node<T>(data);
            child.setParent(this);
            this.children.add(child);
        }

        public void addChild(Node<T> child) {
            child.setParent(this);
            this.children.add(child);
        }

        public T getData() {
            return this.data;
        }

        public void setData(T data) {
            this.data = data;
        }

        public boolean isRoot() {
            return (this.parent == null);
        }

        public boolean isLeaf() {
            return this.children.size() == 0;
        }

        public void removeParent() {
            this.parent = null;
        }
    }
}