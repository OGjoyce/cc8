package IndexStructurePack;

import org.jsoup.Jsoup;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.io.IOException;
import java.util.*;
import java.net.*;

import org.json.simple.JSONObject;;

public class ListLinks {
    @SuppressWarnings("resource")
    public static String path = "C:/Users/julio/Desktop/jQuery/";
	public static PrintWriter writer, metawriter, wrt, escritorDeMeta;
    public static ArrayList<String> linkAnalizado = new ArrayList<String>();
    public static ArrayList<String> linkAnalizadoL1 = new ArrayList<String>();
    public static ArrayList<String> linkAnalizadoL2 = new ArrayList<String>();
    public static ArrayList<String> allLinks = new ArrayList<String>();
    public static Hashtable<String, ArrayList<String>> parentChildren = new Hashtable<String, ArrayList<String>>();
	public static void main(String[] args) throws Exception {
        print("Ingrese un sitio para analizar");
		Scanner sc = new Scanner(System.in);
        String url = sc.nextLine();
        print("Analizando %s...", url);
        writer = new PrintWriter(path + "indexPagina.html");
    	writer.println("<html>");
    	writer.println("<head>");
    	writer.println("<title>Displaying Sitemap</title>");
    	writer.println("</head>");
    	writer.println("<body>");
    	writer.println("<h2>Sitemapping: " + url + "</h2><br>");
    	writer.println("<div id = \"data\">");
    	writer.println("<ul>");
    	writer.println("\t<li> NODO INICIAL: " + url);
    	

    	escritorDeMeta = new PrintWriter(path + "metadata.html");
    	escritorDeMeta.println("<html>");
    	escritorDeMeta.println("\t<body>");
    	escritorDeMeta.println("<title>Metadata</title>");
    	escritorDeMeta.println("<h1>Resumen de Metadatos</h1>");
    	getLinks(url);
    	getMeta(url);
        writer.println("\t</li>");
    	writer.println("</ul>");
    	writer.println("</div>");
    	writer.println("<a href = \"puertos.html\"> RESUMEN DE PUERTOS ABIERTOS </a><br>");
    	writer.println("<a href = \"metadata.html\"> RESUMEN DE META DATA </a><br>");
    	writer.println("<a href = \"media.html\"> RESUMEN DE MEDIA </a>");
    	writer.println("<script src = \"js/jquery-3.3.1.min.js\" type=\"text/javascript\"></script>");
    	writer.println("<script src = \"js/vakata-jstree-0097fab/dist/jstree.min.js\"></script>");
    	writer.println("<script src = \"js/script.js\"></script>");
    	writer.println("</body>");
    	writer.println("</html>");
    	writer.close();
    	
    	
   		wrt = new PrintWriter(path + "media.html");
    	wrt.println("<html>");
    	wrt.println("<body>");
    	wrt.println("<title>Media obtenida</title>");
    	wrt.println("<h1>Media Obtenida</h1>");
    	
    	
    	getMedia(url);
    	getPorts(url);
    }

    private static void print(String msg, Object... args) {
        System.out.println(String.format(msg, args));
    }

    
    private static String trim(String s, int width) {
        if (s.length() > width)
            return s.substring(0, width-1) + ".";
        else
            return s;
    }

    
    private static void getMeta(String url) throws Exception {
    	Document doc = Jsoup.connect(url).get();
        Elements meta = doc.select("meta");

        print("\nMetadata: (%d)", meta.size());
        for (Element data : meta) {	
        	if(!data.attr("charset").equals("") && data.attr("charset") != null) {
        		//print(" * %s: <%s> (%s) content: %s", data.tagName(), data.attr("charset"), data.attr("name"), data.attr("content"));
        		escritorDeMeta.println("<font color=\"blue\"> * " + data.tagName() + " charset: " + data.attr("charset") + "</font><br>");
        	}
        	else if(!data.attr("name").equals("") && data.attr("name") != null) {
        		escritorDeMeta.println("<font color=\"red\"> * " + data.tagName() + " name: " + data.attr("name") + "</font><br>");
        	}
        	else if(!data.attr("content").equals("") && data.attr("content") != null) {
        		escritorDeMeta.println("<font color=\"orange\"> * " + data.tagName() + " content: " + data.attr("content") + "</font><br>");
        	}
        	else {
        		//escritorDeMeta.println(" * " + data.tagName());
        	}
        }
    	escritorDeMeta.println("\t<h2>Fin de Resumen de Metadata</h2>");
    	escritorDeMeta.println("\t</body>");
    	escritorDeMeta.println("</html>");
        escritorDeMeta.close();
    }
    
    
    private static void getLinks(String url) throws Exception{
   	 Document doc = Jsoup.connect(url).get();
        Elements links = doc.select("a[href]");
        allLinks.add(url);
        for (int i=0; i < links.size(); i++) {
       	 Element link = links.get(i);
       	 String urlL1 = link.attr("abs:href");
       	 String urlNameL1 = trim(link.text(), 35);
            //print(" * a: <%s>  (%s)", urlL1, urlNameL1);
       	 	if((!urlL1.contains(url) && !urlL1.contains(url.replaceAll("http", "https")))  && (!allLinks.contains(urlL1) && !urlL1.contains("#") && !urlL1.equals(url + "/"))) {
        		escritorDeMeta.println("<font color=\"green\"> * " + urlL1 + "</font><br>");
       	 	}
       	 
       	 	else if(!allLinks.contains(urlL1) && !urlL1.contains("#") && !urlL1.equals(url + "/")){
	        	 linkAnalizado.add(urlL1);
	        	 allLinks.add(urlL1);
	        }   
        }
        try {
       	 writer.println("\t<ul>");
        for(int i = 0; i < linkAnalizado.size(); i++) {
       	 String urlL1 = linkAnalizado.get(i);
       	 Document doc1 = Jsoup.connect(urlL1).get();
       	 Elements linksL1 = doc1.select("a[href]");
       	 print("");
            print(" * Hijo de Index: <%s> ", urlL1);
            writer.println("\t\t<li>" + urlL1);
            writer.println("\t\t\t<ul>");
            for(int j = 0; j < linksL1.size(); j++) {
           	 Element link = linksL1.get(j);
           	 String urlL2 = link.attr("abs:href");
           	 String urlNameL2 = trim(link.text(), 35);
           	if((!urlL2.contains(url) && !urlL2.contains(url.replaceAll("http", "https"))) && (!allLinks.contains(urlL2) && !urlL2.contains("#") && !urlL2.equals(urlL1 + "/"))) {
        		escritorDeMeta.println("<font color=\"pink\"> * " + urlL2 + "</font><br>");
       	 	}
           	 
           	 else if(!allLinks.contains(urlL2) && !urlL2.contains("#") && !urlL2.equals(urlL1 + "/")){
           		 linkAnalizadoL1.add(urlL2);
   	        	 allLinks.add(urlL2);
   	         }
          
           	 
            }
            try {
            for(int j = 0; j < linkAnalizadoL1.size(); j++) {
           	 String urlLevel2 = linkAnalizadoL1.get(j);
           	 Document docLevel2 = Jsoup.connect(urlLevel2).get();
           	 Elements linksL2 = docLevel2.select("a[href]");
           	 print("");
                print(" * Hijo de Hijo de Index: <%s> ", urlLevel2);
                writer.println("\t\t\t\t<li>" + urlLevel2);
                writer.println("\t\t\t\t\t<ul>");
           	 for(int m = 0; m < linksL2.size(); m++) {
           		 Element link = linksL2.get(m);
           		 String urlLevel3 = link.attr("abs:href");
           		 if((!urlLevel3.contains(url) && !urlLevel3.contains(url.replaceAll("http", "https"))) && (!allLinks.contains(urlLevel3) && !urlLevel3.contains("#") && !urlLevel3.equals(urlLevel2 + "/"))) {
           			 escritorDeMeta.println("<font color=\"pink\"> * " + urlLevel3 + "</font><br>");
           	 	 } 
           		 		
           		 	else if(!allLinks.contains(urlLevel3) && !urlLevel3.contains("#") && !urlLevel3.equals(urlLevel2 + "/")){
	                	 linkAnalizadoL2.add(urlLevel3);
	                	 writer.println("\t\t\t\t\t\t<li> " + urlLevel3);
	        	       	 allLinks.add(urlLevel3);
	        	       	 writer.println("\t\t\t\t\t\t</li>");
	        	    }
           		 }
           	 writer.println("\t\t\t\t\t</ul>");
                writer.println("\t\t\t\t</li> ");
           	 System.out.print("   * Hijos de Hijo de Hijo de Index: ");
                System.out.println(linkAnalizadoL2);
                linkAnalizadoL2.clear();
           	 }
            }catch(IOException e) {}
            writer.println("\t\t\t</ul>");
            writer.println("\t\t</li>");
            linkAnalizadoL1.clear();
        }
       writer.println("\t</ul>");
        }catch (IOException e) {
       	 
        }
        
   }

    
	private static void getMedia(String url) throws Exception{
        Document doc = Jsoup.connect(url).get();
        Elements media = doc.select("[src]");
        print("\nMedia: (%d)", media.size());
        for (Element src : media) {
            if (src.tagName().equals("img"))
                wrt.println("" +src.tagName() + " " + src.attr("abs:src") + " " + src.attr("width") + " " + src.attr("height") + " " +trim(src.attr("alt"), 20) + "<br>");
            else
                wrt.println("" + src.tagName() + " " + src.attr("abs:src") + "<br>");
        }
        wrt.println("</body>");
    	wrt.println("</html>");
        wrt.close();
    }

    
   	private static void getPorts(String hostName) throws Exception{
        PrintWriter escritorDePuertos = new PrintWriter(path + "puertos.html");
    	URL url = new URL(hostName);
    	String host = url.getHost();
    	escritorDePuertos.println("<html>");
    	escritorDePuertos.println("\t<body>");
    	escritorDePuertos.println("<title>resumen de puertos abiertos</title>");
    	escritorDePuertos.println("<h1>Resumen de puertos abiertos</h1>");
    	for(int i = 0; i <= 1024; i++) {
    		Socket socket = new Socket();
        	try {
        		socket.connect(new InetSocketAddress(host,i), 100);
        		socket.close();
        		escritorDePuertos.println("\t<h2>- El Puerto " + i + " esta abierto.</h2>");
        		
        	}catch(IOException e) {

        	}
        }
    	escritorDePuertos.println("\t<h2>Fin de Resumen de Puertos principales abiertos</h2>");

    	escritorDePuertos.println("\t</body>");
    	escritorDePuertos.println("</html>");
    	escritorDePuertos.close();
    }
}