console.log($().jquery);
$(document).ready(function(){	
	$('#data').jstree({
		"plugins": [
			"checkbox",
			"unique"
		],
		"core":{
			"animation" : 0,
			"check_callback" : true,
			"themes" : { "stripes" : true }
		},
		"root" : {
			"icon" : "../assets/tree-icon-png-17.png",
			"valid_children" : ["default"]
		  }
	
	});

	$('#data').on("changed.jstree", function(e, data){
		if (data.selected.length){
			$(data.selected).each(function(idx){
				var node = data.instance.get_node(data.selected[idx]);
			//	console.log('The node is: ' + node.text);
			});
		}
	});
	$(document).on('click', '.jstree-anchor', function(e) {
		var anchorId = $(this).parent().attr('id');
		var anchorValue = $(this).parent().text();
		var clickId = anchorId.substring(anchorId.indexOf('_') + 1, anchorId.length);
		onMenuItemClick(clickId, e, anchorValue);
	});
	function onMenuItemClick(clickId, e, link) {
		var html_content;
		//$.get( link, function( data ) {
		//	html_content = data;
		 // });
		 // 1. Create a new XMLHttpRequest object
let xhr = new XMLHttpRequest();

// 2. Configure it: GET-request for the URL /article/.../load
xhr.open('GET', 'localhost:8090/index.html');

// 3. Send the request over the network
xhr.send();

// 4. This will be called after the response is received
xhr.onload = function() {
  if (xhr.status != 200) { // analyze HTTP status of the response
    alert(`Error ${xhr.status}: ${xhr.statusText}`); // e.g. 404: Not Found
  } else { // show the result
    alert(`Done, got ${xhr.response.length} bytes`); // responseText is the server
  }
};

xhr.onprogress = function(event) {
  if (event.lengthComputable) {
    alert(`Received ${event.loaded} of ${event.total} bytes`);
  } else {
    alert(`Received ${event.loaded} bytes`); // no Content-Length
  }

};

xhr.onerror = function() {
  alert("Request failed");
};
		var html =  '<div id="modalWindow" class="modal fade" >';
    html += '<div class="modal-header">';
    html += '<a class="close" data-dismiss="modal">×</a>';
    html += '<h4>Https</h4>'
    html += '</div>';
	html += '<div class="modal-body">';
	html += '<iframe src="https://www.google.com" width="100%" height="480" >'+link+'</iframe>'
    html += '</div>';
    html += '<div class="modal-footer">';
    html += '<span class="btn" data-dismiss="modal">';
    html += 'Close';
    html += '</span>'; // close button
    html += '</div>';  // footer
    html += '</div>';  // modalWindow
	$("#bodyfull").html(html);
		// Show the Modal on load
		$("#modalWindow").modal("show");
		  
	
	
	
	
	}
	
	
});