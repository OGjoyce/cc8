/*
Genera un request a una pagina, obtiene su HTML y crea el objeto HTMLParser.java
*/
import java.net.*;
import java.io.*;

public class SocketRequesting {

  public static void main(String[] args)throws Exception {

    int port = 80;

    for (int i = 0; i < args.length; i++) {
      try {
         URL u = new URL(args[i]);
         if (u.getPort() != -1) port = u.getPort();
         Socket s = new Socket(u.getHost(), port);
         OutputStream theOutput = s.getOutputStream();
         // no auto-flushing
         PrintWriter pw = new PrintWriter(theOutput, false);
         // native line endings are uncertain so add them manually
         if(u.getFile().equals("")){
             System.out.println(u);
            URL nuevo_u = new URL(args[i]+"/index.html");
            u = nuevo_u;
         }
         pw.print("GET " + u.getFile() + " HTTP/1.0\r\n");
         pw.print("Accept: text/plain, text/html, text/*\r\n");
         pw.print("\r\n");
         pw.flush();
         InputStream in = s.getInputStream();
         InputStreamReader isr = new InputStreamReader(in);
         BufferedReader br = new BufferedReader(isr);
         int c;
         String html = "";
         while ((c = br.read()) != -1) {
          // System.out.print((char) c);
           html = html+(char)c;
         }
         System.out.println(html);
         HTMLParser object_html = new HTMLParser(html, args[i], u.getFile());
        
      }
      catch (MalformedURLException ex) {
        System.err.println(args[i] + " is not a valid URL");
      }
      catch (IOException ex) {
        System.err.println(ex);
      }

    }

  }

}