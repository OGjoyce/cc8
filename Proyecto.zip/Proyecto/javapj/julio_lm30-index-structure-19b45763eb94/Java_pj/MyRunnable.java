import java.io.IOException;

public class MyRunnable implements Runnable {
    public int Tnumber;
    public Boolean worked;
    public String Thost;
   public MyRunnable(int port, String host) {
       // store parameter for later user
       this.Tnumber = port;
       this.Thost = host;
       

   }
   public void run() {
       try{
    WebProtocols wp = new WebProtocols("cliente", this.Tnumber, this.Thost);
    if(!wp.bt){
        this.worked = true;

    }
    else{
        this.worked=false;
    }
   
       }
       catch(IOException e ){
           System.out.println("Exception!");
       }

       if (this.worked)
        System.out.println("Thread is good: "+ this.Tnumber + "host: "+this.Thost);
    
     }

}