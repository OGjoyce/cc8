/*
Este codigo obtiene todas las etiquetas <a> de un html, usado en SocketRequesting.java
*/
import java.util.*;
import java.io.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
 
public class HTMLParser{
    public static Set<String> uniqueURL = new HashSet<String>();
    String html;
    String domain;
    String came;
    public HTMLParser(String html, String domain, String came) throws Exception
    {
        this.html=html;
        this.domain=domain;
        this.came=came;
        this.parser(html);
    }
    public void parser(String s)throws Exception{
         try {
            Document doc = Jsoup.parse(s);
            Elements links = doc.select("a");

            if (links.isEmpty()) {
               return;
            }

            links.stream().map((link) -> link.attr("abs:href")).forEachOrdered((this_url) -> {
                boolean add = uniqueURL.add(this_url);
                if (add && this_url.contains(this.came)) {
                    System.out.println(this_url);
                    get_links(this_url);
                   
                }
            });

        } catch (Exception ex) {

        }
       
     
    }
    private void get_links(String url) {
        try {
            Document doc = Jsoup.connect(url).userAgent("Mozilla").get();
            Elements links = doc.select("a");

            if (links.isEmpty()) {
               return;
            }

            links.stream().map((link) -> link.attr("abs:href")).forEachOrdered((this_url) -> {
                boolean add = uniqueURL.add(this_url);
                uniqueURL.add(this_url+"#");
                if (add && this_url.contains(this.domain)) {
                    System.out.println(this_url);
                    get_links(this_url);
                }
            });

        } catch (IOException ex) {

        }

    }
    public static void main(String[] args) {
        
    }
}