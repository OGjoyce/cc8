
function getHref(links, as){
    var as_length = as.length;
    var links_length = links.length;
    for (let index = 0; index < as_length; index++) {
        var element = as[index].href;
        $("#div1").html($("#div1").html()+`<br>> ${element}`);

        if(element.indexOf(window.location.href)>-1){
            $("#div1").html($("#div1").html()+` - <p style='color:purple;'> current path DETECTED action: discarting... </p>`);
            element="0";
            
         } 

        if(element.indexOf("file:///C:/") > -1) {
            element = element.replace("file:///C:/", initiator);
            $("#div1").html($("#div1").html()+` -   ${element}`);
         }
         else if(element.indexOf(initiator)> -1){
            $("#div1").html($("#div1").html()+` - ${element}`);
          
         }
         else if(element.indexOf("file://") > -1) {
            element = element.replace("file://", initiator);
            $("#div1").html($("#div1").html()+` - <p style='color:red;'> External domain DETECTED action: discarting...</p>`);
    
         }
         else if(element.indexOf("mailto:") > -1) {
           element =0;
            $("#div1").html($("#div1").html()+` - <p style='color:cyan;'> External action DETECTED action: discarting... </p>`);
         }
         else if(element.indexOf("tel:") > -1) {
            element=0;
            $("#div1").html($("#div1").html()+` - <p style='color:cyan;'> External action DETECTED action: discarting...</p>`);
         }
        
         
         getHtmlChild(element);
     
           


    } 
}
function parseHtml(htmls)
{  // console.log(html);
    
    $("#div1").html($("#div1").html()+"<br>>Parsing...");
    var ele = document.createElement('div');
    ele.innerHTML = htmls;
    console.log(ele);
    var link_tag = ele.getElementsByTagName('link');
    var a_tag = ele.getElementsByTagName('a');
    $("#div1").html($("#div1").html()+`<br>>found ${link_tag.length} <b><u>link</u></b> tags and ${a_tag.length} <b><u>a</u></b> tags., BAD TAGS ARE ELIMINATED! `);
    getHref(link_tag, a_tag);
    //console.log(link_tag[0].href);
}
function getHtml(urls){
    console.log("INICIADOR:" + urls);
    if(urls[urls.length-1]!="/"){
        urls = urls+"/";
      
    }    
    initiator=urls;
    proceses++;
    $.ajax({
        url: `${urls}`,
        method: "GET",
        crossDomain: true,
        success: function(data) {
            $("#div1").html(">Content is succefull gathered....");
            parseHtml(data);
        }
    });
}

