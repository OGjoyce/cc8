var initiatorChild = '';
var global_element2 = document.createElement('div');
function getHrefChild(links, as){
    var as_length = as.length;
    var links_length = links.length;
    for (let index = 0; index < as_length; index++) {
        var element = as[index].href;
       // $("#div1").html($("#div1").html()+`<br>> ${element}`);

        if(element.indexOf(window.location.href)>-1){
            $("#div1").html($("#div1").html()+` - <p style='color:purple;'> current path DETECTED action: discarting... </p>`);
            links_discarted.push(element);
            element="0";
            
            
         } 

        if(element.indexOf("file:///C:/") > -1) {
            element = element.replace("file:///C:/", initiatorChild);
           // $("#div1").html($("#div1").html()+` -   ${element}`);
         }
         else if(element.indexOf(initiatorChild)> -1){
            //$("#div1").html($("#div1").html()+` - ${element}`);
          
         }
         else if(element.indexOf("file://") > -1) {
            element = element.replace("file://", initiatorChild);
            $("#div1").html($("#div1").html()+` - <p style='color:red;'> External domain DETECTED action: discarting...</p>`);

         }
         else if(element.indexOf("mailto:") > -1) {
            links_discarted.push(element);
           element =0;
            $("#div1").html($("#div1").html()+` - <p style='color:cyan;'> External action DETECTED action: discarting... </p>`);
         }
         else if(element.indexOf("tel:") > -1) {
            links_discarted.push(element);
            element=0;
            $("#div1").html($("#div1").html()+` - <p style='color:cyan;'> External action DETECTED action: discarting...</p>`);
         }
        
         
         links_readed.push(element);
         initiatorChild = element;
        getHtmlChild(element); 
     
           



}
}


function parseChildHtml(htmls){
      
    $("#div1").html($("#div1").html()+"<br>>>Parsing child...");
    global_element2.innerHTML = htmls;
   
    var link_tag = global_element2.getElementsByTagName('link');
    var a_tag = global_element2.getElementsByTagName('a');
    $("#div1").html($("#div1").html()+`<br>>found ${link_tag.length} <b><u>link</u></b> tags and ${a_tag.length} <b><u>a</u></b> tags., BAD TAGS ARE ELIMINATED! `);
    getHrefChild(link_tag, a_tag);
    //console.log(link_tag[0].href);
}

function getHtmlChild(url1){
    if(url1 != 0 && url1 != initiator){
        initiatorChild = url1;
        console.log(url1);
        //getHtml_recursivity(initiator, url1);
    $("#div1").html($("#div1").html()+`<br>>> Entering and gathering from ${url1}`);
    var inct = url1;
    proceses++;
    $.get(`${url1}`, function(data) {
		$("#div1").html($("#div1").html()+`<br>>>(child ${url1})Content is succefull gathered....`);
            parseChildHtml(data);
	});
    }
    //console.log(links_readed);
}