var initiator = '';
var home = '';
var proceses = 0;
var links_processed=new Array();  
var links_readed = new Array();
var links_discarted = new Array();
alert(window.location.hostname);
var global_element = document.createElement('div');


function getHref(links, as){
    var as_length = as.length;
    var links_length = links.length;
    for (let index = 0; index < as_length; index++) {
        var element = as[index].href;
      //  $("#div1").html($("#div1").html()+`<br>> ${element}`);

        if(element.indexOf(window.location.href)>-1){
            $("#div1").html($("#div1").html()+` - <p style='color:purple;'> ${element} current path DETECTED action: discarting... </p>`);
            links_discarted.push(element);
            element="0";
            
            
         } 
         if(element.indexOf(window.location.hostname) > -1) {
            element = element.replace("http://"+window.location.hostname+":"+location.port, initiator);
            element = element.replace("https://"+window.location.hostname+":"+location.port, initiator);
            $("#div1").html($("#div1").html()+` -   ${element}`);

         }
        if(element.indexOf("file:///C:/") > -1) {
            element = element.replace("file:///C:/", initiator);
            $("#div1").html($("#div1").html()+` -   ${element}`);
      
         }
         else if(element.indexOf(initiator)> -1){
            $("#div1").html($("#div1").html()+` - ${element}`);
         
          
         }
         else if(element.indexOf("file://") > -1) {
            element = element.replace("file://", initiator);
            $("#div1").html($("#div1").html()+` - <p style='color:red;'> External domain DETECTED action: discarting...</p>`);
           
         }
         else if(element.indexOf("mailto:") > -1) {
            links_discarted.push(element);
           element =0;
            $("#div1").html($("#div1").html()+` - <p style='color:cyan;'> External action DETECTED action: discarting... </p>`);
         }
         else if(element.indexOf("tel:") > -1) {
            links_discarted.push(element);
            element=0;
            $("#div1").html($("#div1").html()+` - <p style='color:cyan;'> External action DETECTED action: discarting...</p>`);
         }
        
        
         links_readed.push(element);
            getHtmlChild(element);
        
        
 
     
           


    } 
}


function parseHtml(htmls)
{  // console.log(html);
    
    $("#div1").html($("#div1").html()+"<br>>Parsing...");
    global_element.innerHTML = htmls;
   
    var link_tag = global_element.getElementsByTagName('link');
    var a_tag = global_element.getElementsByTagName('a');
    $("#div1").html($("#div1").html()+`<br>>found ${link_tag.length} <b><u>link</u></b> tags and ${a_tag.length} <b><u>a</u></b> tags., BAD TAGS ARE ELIMINATED! `);
    getHref(link_tag, a_tag);
    //console.log(link_tag[0].href);
}
function getHtml(urls){
    console.log("INICIADOR:" + urls);
    if(links_processed){
        links_processed.push(urls);
    }
    if(urls[urls.length-1]=="/"){
        urls[urls.length-1]="";
      
    }    
    initiator=urls;
    proceses++;
   
    $.get(`${urls}`, function(data) {
		$("#div1").html($("#div1").html()+`${urls}`+">Content is succefull gathered....");
           parseHtml(data);
	});
}
